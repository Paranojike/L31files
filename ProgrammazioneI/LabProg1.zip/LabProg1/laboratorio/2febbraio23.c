#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Prenda in input da riga di comando un parametro stringa “input” che contenga il nome di un 
file con estensione “txt” (ad esempio “file_di_input.txt”), e un parametro stringa “output” che 
contenga il nome di un file con estensione “txt” (ad esempio “file_di_output.txt”). Il 
programma controlla che l’utente abbia specificato il numero corretto di parametri e che i 
nomi dei file abbiano effettivamente estensione “txt”.*/

typedef struct Record{
    char nome[255];
    char cognome[255];
    int numero_conto;
    int anno_apertura;
    float saldo;
}record;

typedef struct Nodo{
    record data;
    struct Nodo* next;
}nodo;


typedef struct Lista{
    nodo* head;
}lista;



typedef struct Argomenti{

char file_input[255];
char file_output[255];

}Arg;


Arg decodeParameters(int argc, char* argv[]){

    if(argc!=3){
        fprintf(stderr,"Numero argomenti erraro\n");
        exit(-1);
    }

    Arg in;

    strcpy(in.file_input, argv[1]);
    strcpy(in.file_output, argv[2]);

    if(strcmp(strrchr(in.file_input,'.'), ".txt")){
        fprintf(stderr, "Estensione file input errata\n");
        exit(-1);
    }

    if(strcmp(strrchr(in.file_output,'.'), ".txt")){
        fprintf(stderr,"Estensione file output errata\n");
        exit(-1);
    }


return in;
}


lista* getList(void){

    lista* Lista = malloc(sizeof(lista));
    if(Lista == NULL){
        fprintf(stderr, "Impossibile allocare lista\n");
        exit(-1);
    }
    Lista->head = NULL;
return Lista;
}



void insert(record r, lista* Lista){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = r;

    if(Lista->head == NULL){
        newnode->next = NULL;
        Lista->head = newnode;
    } else {
        if(newnode->data.anno_apertura <= Lista->head->data.anno_apertura){
            newnode->next = Lista->head;
            Lista->head = newnode;
        }else{
            nodo* current = Lista->head;
            while(current->next != NULL && newnode->data.anno_apertura > current->next->data.anno_apertura){
                current = current->next;
            }

            newnode->next = current->next;
            current->next = newnode;
        }
    }


}


int readFile(lista* Lista, Arg ag){

    FILE* fPtr = fopen(ag.file_input, "r");
    if(fPtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    while(1){
        record r;
        fscanf(fPtr, "%s %s %d %d %f", r.nome, r.cognome, &r.numero_conto, &r.anno_apertura, &r.saldo);
        insert(r, Lista);
        if(feof(fPtr)) break;
    }


    int counter = 0;
    nodo* tmp = Lista->head;
    printf("Contenuto lista:\n");
    while(tmp!=NULL){
        printf("%s %s %d %d %f\n", tmp->data.nome, tmp->data.cognome, tmp->data.numero_conto, tmp->data.anno_apertura, tmp->data.saldo);
        tmp = tmp->next;
        counter++;
    }
return counter;
}

float getMax(lista* Lista){

    nodo* tmp = Lista->head;
    float max = tmp->data.saldo;

    while(tmp!=NULL){
    if(tmp->data.saldo > max){
        max = tmp->data.saldo;
    }
    tmp = tmp->next;
    }

return max;
}


float findX(float max, float saldo, float anno){

    float opB = saldo/max;

    float opA = (2023-anno)/5;

    float min = 0;
    if(opA < 1){
        min = opA;
    }else{
        min = 1;
    }

    float X = min*opB;

return X;

}


void delete(lista* Lista, int num){

    if(Lista->head == NULL){
        fprintf(stderr, "Lista vuota\n");
        exit(-1);
    }

    nodo* tmp = Lista->head;
    nodo* prev = NULL;


    if(tmp!=NULL && tmp->data.numero_conto == num){
        Lista->head = tmp->next;
        free(tmp);
        return;//pop della pila 
    }


    while(tmp!=NULL && tmp->data.numero_conto != num){
        prev = tmp;
        tmp = tmp->next;
    }

    if(tmp!=NULL){
        prev->next = tmp->next;
        free(tmp);
    }

}


void removeAccount(lista* Lista){

    float max = getMax(Lista);
    nodo* MAX_NODE = NULL;
    nodo* tmp = Lista->head;
    float max_x = 0;

    while(tmp!=NULL){
        float x = findX(max, tmp->data.saldo,tmp->data.anno_apertura);
        if(x > max_x){
            max_x = x;
            MAX_NODE = tmp;
        }

    tmp = tmp->next;
    } 
    printf("%s %s %d %d %f\n", MAX_NODE->data.nome, MAX_NODE->data.cognome, MAX_NODE->data.numero_conto, MAX_NODE->data.anno_apertura, MAX_NODE->data.saldo);
    delete(Lista, MAX_NODE->data.numero_conto);

}



void writeFile(lista* Lista, Arg ag){

    FILE* filePtr = fopen(ag.file_output, "w");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    nodo* tmp = Lista->head;
    while(tmp!=NULL){
        fprintf(filePtr, "%s %s %d %d %f\n", tmp->data.nome,tmp->data.cognome, tmp->data.numero_conto, tmp->data.anno_apertura, tmp->data.saldo);
        tmp = tmp->next;
    }
fclose(filePtr);

}

int main(int argc, char* argv[]){

    Arg ag = decodeParameters(argc, argv);
    printf("File input: %s\nFile output: %s\n", ag.file_input, ag.file_output);

    lista* Lista = getList();
    int n = readFile(Lista, ag);

    int h = n/2;
    printf("\n\n");
    for(int i = 0; i < h; i++){
        removeAccount(Lista);
    }

    writeFile(Lista, ag);


    while(Lista->head!=NULL){
        nodo* tmp = Lista->head;
        Lista->head = Lista->head->next;
        //free(tmp->data); non ne ho bisogno in questo caso perchè il record è statico e non dinamico
        free(tmp);
    }
    free(Lista);

}