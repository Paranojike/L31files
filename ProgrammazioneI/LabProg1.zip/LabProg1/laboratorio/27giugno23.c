#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*Prenda in input da riga di comando un parametro stringa filename che contenga un nome di 
file di output (ad esempio “file_di_output.bin”) e un parametro intero n. Il programma 
controlli che il nome del file abbia estensione “bin” e che n sia compreso tra 3 e 5*/

//numeroConto nome cognome saldo
typedef struct Record {
    int numeroConto;
    char nome[255];
    char cognome[255];
    float saldo;
}record;

typedef struct Nodo{
    record data;
    struct Nodo* next;
}nodo;

typedef struct Coda{
    nodo* head;
    nodo* tail;
}coda;

typedef struct Argomenti{
    char file_output[255];
    int n;
}Arg;


Arg decodeParameters(int argc, char*argv[]){

    if(argc!=3){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }


    Arg in;

    strcpy(in.file_output, argv[1]);
    in.n = atoi(argv[2]);

    if(strcmp(strrchr(in.file_output, '.'), ".bin")){
        fprintf(stderr, "Estensione file errata\n");
        exit(-1);
    }

    if(in.n < 3 || in.n > 5){
        fprintf(stderr, "Paramentro n errato\n");
        exit(-1);
    }
return in;

}


coda* getList(void){

    coda* Coda = malloc(sizeof(coda));
    if(Coda == NULL){
        fprintf(stderr, "Impossibile allocare coda\n");
        exit(-1);
    }
    Coda->head = NULL;    
    return Coda;
}



record readRecord(void){
    record r;
    scanf("%d %s %s %f", &r.numeroConto, r.nome, r.cognome, &r.saldo);

return r;
}

void enqueue(coda* Coda, record r){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }
    newnode->data = r;
    newnode->next = NULL;

    if(Coda->tail == NULL){
        Coda->tail = newnode;
        Coda->head = newnode;
    }else{
        Coda->tail->next = newnode;
        Coda->tail = newnode;
    }


}

void loadRecord(coda* Coda){

    while(1){
        record r;
        r = readRecord();
        if(feof(stdin)) break;
        enqueue(Coda, r);
    }


}


int printList(coda* Coda){
 nodo* tmp = Coda->head;
 int counter = 0;
    printf("\n\nCodaaaaa: \n");
    while(tmp!=NULL){
        printf("%d %s %s %.2f\n", tmp->data.numeroConto, tmp->data.nome, tmp->data.cognome, tmp->data.saldo);
        tmp = tmp->next;
        counter++;
    }
return counter;
}


record* getArray(coda* Coda, int counter){

    record* X = malloc(sizeof(record) * counter);
    nodo* tmp = Coda->head;
    
    for(int i = 0; i < counter; i++){
        X[i] = tmp->data;
        tmp = tmp->next;
    }
    
    return X;
}



void selectionSort(record* X, int n){

record tmp;
    for(int i = 0; i < n-1; i++){
        int min = i;
        for(int j = i+1; j < n; j++){
            if(X[j].saldo < X[min].saldo){
                min = j;
            }
        }

        tmp = X[i];
        X[i] = X[min];
        X[min] = tmp;
    }

}
//zauuuuuuuuu tvb ciccina 


unsigned int get_random() {
    static unsigned int m_w = 424242;
    static unsigned int m_z = 242424;
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}


void scanfile(FILE* filePtr){
    record r;
    fread(&r, sizeof(record), 1, filePtr); // Leggi il record dal file
    printf("%d %s %s %.2lf\n", r.numeroConto, r.nome, r.cognome, r.saldo);

}

void showFileContent(FILE* filePtr){

    printf("Contenuto file binario:\n");
    for(int i = 0; i < 5; i++){
        unsigned int rand = get_random() % 6;
        fseek(filePtr, sizeof(record) * rand, SEEK_SET);
        scanfile(filePtr);
    }

}

void saveToFile(record* X, Arg ag, int counter){

    FILE* filePtr = fopen(ag.file_output, "wb+");
    if(filePtr == NULL){
        fprintf(stderr, "Il file non può essere aperto\n");
        exit(-1);
    }
    fwrite(X, sizeof(record), counter, filePtr);

    rewind(filePtr);
    showFileContent(filePtr);
}


int main(int argc, char*argv[]){

    Arg ag = decodeParameters(argc, argv);
    printf("Filename: %s\nParamentro n: %d\n", ag.file_output, ag.n);

    coda* Coda = getList();
    loadRecord(Coda);

    int counter = printList(Coda);

    record* X = getArray(Coda, counter);

    selectionSort(X, counter);

    printf("Array \n");
    for(int i = 0; i < counter; i++){
        printf("%d %s %s %.2f\n", X[i].numeroConto, X[i].nome, X[i].cognome, X[i].saldo);
    }

    saveToFile(X, ag, counter);
    

}