/*Prenda in input da riga di comando un parametro stringa alfabeto, un intero n e un nome di 
file output (ad esempio “file_di_output.txt”). Il programma controlla che la stringa alfabeto 
abbia una lunghezza compresa tra 5 e 15 caratteri (inclusi) e che l’intero n sia compreso tra 5 
e 20 (inclusi)*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct Argomenti{
    char alfabeto[255];
    int n;
    char file_output[255];
}Arg;


typedef struct Nodo{
    char* data;
    struct Nodo* next;
}nodo;

typedef struct Lista{
    nodo* head;
}pila;



Arg decodeParameters(int argc, char*argv[]){

    if(argc!=4){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg in;

    strcpy(in.alfabeto, argv[1]);
    in.n = atoi(argv[2]);
    strcpy(in.file_output, argv[3]);

    if(in. n < 5 || in.n > 20){
        fprintf(stderr, "Paramentro n errato\n");
        exit(-1);
    }

    if(strlen(in.alfabeto) < 5 || strlen(in.alfabeto) > 15){
        fprintf(stderr, "Paramentro n errato\n");
        exit(-1);
    }

return in;

}



int modifyArray(int x, int L){

    int max = 0;
    if(x > 1){
        max = x;
    }else {
        max = 1;
    }

    int min = 0;
    if(max < L){
        min = max;
    }else{
        min = L;
    }

return min;
}

int* readInput(Arg ag){

    int* A = malloc(sizeof(int) * ag.n);
    int len = strlen(ag.alfabeto);

    for(int i = 0 ; i < ag.n; i++){
        scanf("%d", &A[i]);
        A[i] = modifyArray(A[i], len);
    }


    printf("Array:\n");
    for(int i = 0 ; i < ag.n; i++){
        printf("%d\t", A[i]);
    }
    printf("\n");


return A;

}

unsigned int get_random() {
    static unsigned int m_w = 424242;
    static unsigned int m_z = 242424;
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}

char* sampleString(int h, char* Qstr, Arg ag){

    int L = strlen(ag.alfabeto);

    for(int i = 0; i < h; i++){
        unsigned int randindex = get_random() % L;
        Qstr[i] = ag.alfabeto[randindex];
    }

return Qstr;
}


char** getStringArray(int* W, Arg ag){

    char** Qstr = malloc(sizeof(char*) * ag.n);
    for(int i = 0; i < ag.n; i++){
        Qstr[i] = malloc(sizeof(char) * W[i]);
        Qstr[i] = sampleString(W[i], Qstr[i], ag); 
    }

return Qstr;
}


pila* getList(void){

    pila* Stack = malloc(sizeof(pila));
    if(Stack == NULL){
        fprintf(stderr, "Impossibile allocare Stack\n");
        exit(-1);
    }

    Stack->head = NULL;

return Stack;

}




void push(char* Q, pila* Stack){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = Q;

    if(Stack->head == NULL){
        newnode->next = NULL;
        Stack->head = newnode;
    }else{
        newnode->next = Stack->head;
        Stack->head = newnode;
    }

}

char* pop(pila* Stack){

    if(Stack->head == NULL){
        fprintf(stderr, "Pila vuota\n");
        exit(-1);
    }


    char* RetStr = Stack->head->data;

    nodo* tmp = Stack->head;
    Stack->head = tmp->next;
    free(tmp);

return RetStr;
}

void getStack(pila* Stack, char** Q, Arg ag){

    for(int i = 0; i < ag.n; i++){
        if(strlen(Q[i]) % 2 == 0 || Stack->head == NULL){
            push(Q[i], Stack);
        }else{
            char* Str = pop(Stack);
            strcat(Str,Q[i]);
            push(Str, Stack);
        }
    }

   
}



void saveToFile(pila* Stack, Arg ag){

    nodo* tmp = 


}


int main(int argc, char*argv[]){

    Arg ag = decodeParameters(argc, argv);
    printf("Stringa alfabeto: %s\nParametro n: %d\nFile di output: %s\n", ag.alfabeto, ag.n, ag.file_output);

    int* W = readInput(ag);

    char** Q = getStringArray(W, ag);
    for(int i = 0; i < ag.n; i++){
        printf("%s\n", Q[i]);
    }

    pila* Stack = getList();
    getStack(Stack, Q, ag);

    saveToFile(Stack, ag);


}