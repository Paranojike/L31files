

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Argomenti{
    char file_input[255];
    int n;
    char file_output[255];
}Arg;


typedef struct Nodo{
    char* data;
    struct Nodo* next;
}nodo;

typedef struct Queue{
    nodo* head;
    nodo* tail;
}queue;

Arg decodeParameters(int argc, char* argv[]){

    if(argc!=4){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }


    Arg in;

    in.n = atoi(argv[2]);
    if(in.n < 3 || in.n > 12){
        fprintf(stderr, "Intervallo valore n errato\n");
        exit(-1);
    }


    strcpy(in.file_input, argv[1]);
    strcpy(in.file_output, argv[3]);

    FILE* filePtr = fopen(in.file_input, "r");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire %s\n", in.file_input);
        exit(-1);
    }

    char BuffStr[100];
    fscanf(filePtr, "%s", BuffStr);
    if(strlen(BuffStr) < 3 || strlen(BuffStr) > 12){
        fprintf(stderr, "Lunghezza stringa nel file di input errata\n");
        exit(-1);
    }

    printf("Parametri:\nFile input: %s\nFile output: %s\nStringa file: %s\nIntero n: %d\n", in.file_input, in.file_output, BuffStr, in.n);
    fclose(filePtr);

return in;
}

int genFib(int n){
    if(n == 0 || n == 1){
        return n;
    }else{
        return genFib(n-1) + genFib(n-2);
    }

}

int* fibonacci(Arg ag){

    int* F = malloc(sizeof(int) * ag.n);
    for(int i = 0; i < ag.n; i++){
    F[i] = genFib(i);
    }

    printf("Array fibonacci:\n");
    for(int i = 0; i < ag.n; i++){
        printf("%d\t", F[i]);
    }
    printf("\n");

return F;
}

/*C. [7 punti] Costruisca un array di stringhe B di lunghezza n il cui i-esimo elemento B[i] sia una 
stringa di lunghezza A[i] di caratteri casuali estratti dalla stringa alfabeto contenuta all’interno 
del file input.*/

unsigned int get_random() {
 static unsigned int m_w = 424242;
 static unsigned int m_z = 242424;
 m_z = 36969 * (m_z & 65535) + (m_z >> 16);
 m_w = 18000 * (m_w & 65535) + (m_w >> 16);
 return (m_z << 16) + m_w;
}


char* sampleString(int h, char* alfabeto){

    unsigned int len_alf = strlen(alfabeto);

    char* Str = malloc(sizeof(char) * (h+1));

    for(int i = 0; i < h; i++){
        unsigned int randind = get_random() % len_alf;
        Str[i] = alfabeto[randind];
    }
    Str[h] = '\0';  //quando generi la stringa aggiungi il carattere di terminazione (potrebbe essere la causa dei caratteri corrotti!)
    
return Str;

}

char** getStringArray(int* A, Arg ag){

    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire %s\n", ag.file_input);
        exit(-1);
    }

    char alfabeto[12];
    fscanf(filePtr, "%s", alfabeto);

    char** Bstr = malloc(sizeof(char*) * (ag.n+1));
    for(int i = 0; i < ag.n; i++){
        Bstr[i] = sampleString(A[i], alfabeto);
    }


    for(int i = 0; i< ag.n; i++){
        printf("%s\n", Bstr[i]);
    }

    fclose(filePtr);

return Bstr;
}


queue* getList(void){

    queue* Coda = malloc(sizeof(queue));
    if(Coda == NULL){
        fprintf(stderr, "Impossibile allocare coda\n");
        exit(-1);
    }

    Coda->head = NULL;
    Coda->tail = NULL;

return Coda;
}


void enqueue(char* B, queue* Coda){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = B;
    newnode->next = NULL;

    if (Coda->tail == NULL) {
        Coda->tail = newnode;
        Coda->head = newnode;
    } else {
        Coda->tail->next = newnode;
        Coda->tail = newnode;
    }

   
}

char* dequeue(queue* Coda) {

    if (Coda->head == NULL) {
        fprintf(stderr, "Coda vuota\n");
        exit(-1);
    }

    nodo* tmp = Coda->head;
    char* deqStr = tmp->data;
    Coda->head = tmp->next;

    if (Coda->head == NULL) {
        Coda->tail = NULL;
    }

    free(tmp);

    return deqStr;

}


void getQueue(queue* Coda, char** B, int n) {
    for (int i = 0; i < n; i++) {
        if (strlen(B[i]) % 2 == 0 || Coda->head == NULL) {
            enqueue(B[i], Coda);
        } else {
            char* estract = dequeue(Coda);
            char* newStr = malloc(sizeof(char) * (strlen(estract) + strlen(B[i]) + 1));
            strcpy(newStr, estract);
            strcat(B[i], newStr);
            enqueue(B[i], Coda); //se le stringhe non danno l'output del professore, probabilmente devi scambiare i due argomenti
            // in strcat, invece di newStr, B[i] --> B[i], newStr e poi mandi B[i]
        }
    }
}

void visitLista(queue* Coda){

    nodo* tmp = Coda->head;
    printf("Coda:\n");
    while(tmp!=NULL){
        printf("%s\n", tmp->data);
        tmp = tmp->next;
    }
}

int main(int argc, char* argv[]){

    Arg ag = decodeParameters(argc, argv);
    
    int* A = fibonacci(ag);

    char** B = getStringArray(A, ag);
    
    queue* Coda = getList();

    getQueue(Coda, B, ag.n);

    visitLista(Coda);


    

}