#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>



typedef struct Argomenti{
    char file_input[255];
    char file_output[255];
}Arg;

typedef struct Record{
    char nome[255];
    char cognome[255];
    int età;
    int peso;
    int altezza;
    char sesso;
}record;

typedef struct Nodo{
    record data;
    struct Nodo* next;
}nodo;

typedef struct List{
    nodo* head;
}list;


Arg decodeParameters(int argc, char* argv[]){

    if(argc != 3){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg in;

    strcpy(in.file_input, argv[1]);
    strcpy(in.file_output, argv[2]);

    if(strcmp(strrchr(in.file_input,'.'), ".txt")){
        fprintf(stderr, "Estensione file input errata.\n");
        exit(-1);
    }
    if(strcmp(strrchr(in.file_output,'.'), ".txt")){
        fprintf(stderr, "Estensione file output errata.\n");
        exit(-1);
    }


return in;
}


list* getList(void){

    list* Lista = malloc(sizeof(list));
    if(Lista == NULL){
        fprintf(stderr, "Impossibile allocare Lista\n");
        exit(-1);
    }

    Lista->head = NULL;

    return Lista;
}



void insert(list* Lista, record r){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = r;

    if(Lista->head == NULL){
        newnode->next = NULL;
        Lista->head = newnode;
    }else {
        if(newnode->data.età <= Lista->head->data.età){
            newnode->next = Lista->head;
            Lista->head = newnode;
        } else {
            nodo* current = Lista->head;
            while(current->next != NULL && newnode->data.età > current->next->data.età){
                current = current->next;
            }

            newnode->next = current->next;
            current->next = newnode;
        }
    }

}

list* readFile(list* Lista, Arg ag){

    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    while(1){
        record r;
        fscanf(filePtr, "%s %s %d %d %d %c", r.nome, r.cognome, &r.età, &r.peso, &r.altezza, &r.sesso);
        if(feof(filePtr)) break;
        insert(Lista, r);
    }


    nodo* tmp = Lista->head;
    printf("Contenuto lista: \n");
    while(tmp!=NULL){
        printf("%s %s %d %d %d %c\n", tmp->data.nome, tmp->data.cognome, tmp->data.età, tmp->data.peso, tmp->data.altezza, tmp->data.sesso);
        tmp = tmp->next;
    }

    fclose(filePtr);

return Lista;
}


/*Determini l’elemento in A con più alto indice di massa corporea. Dato un soggetto di peso p 
(in kg) e altezza a (in cm), l’indice di massa corporea è calcolato come segue

    IMC = p / (a/100)^2

*/

double getIMC(int peso, int altezza){

    double IMC = 0;

    double base = (double)altezza/100;

    base = base * base;

    IMC = peso/base;

return IMC;
}


void delete(list* Lista, int età){

    if(Lista->head == NULL){
        fprintf(stderr, "Lista vuota\n");
        exit(-1);
    }

    nodo* tmp = Lista->head;
    nodo* prev = NULL;

    if(tmp!=NULL && tmp->data.età == età){
        Lista->head = tmp->next;
        free(tmp);
        return;
    }

    while(tmp!= NULL && tmp->data.età != età){
        prev = tmp;
        tmp = tmp->next;
    }

    if(tmp!= NULL){
        prev->next = tmp->next;
        free(tmp);
    }

}



void insertB(list* ListaB, record rd){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = rd;

    if(ListaB->head == NULL){
        newnode->next = NULL;
        ListaB->head = newnode;
    }else{
        newnode->next = ListaB->head;
        ListaB->head = newnode;
    }

}

void getMax(list* Lista, list* ListaB){


    nodo* tmp = Lista->head;
    nodo* NODE_MAX = NULL;
    double maxIMC = 0;
    double imc = 0;

    while(tmp!=NULL){
        imc = getIMC(tmp->data.peso, tmp->data.altezza);
        if(imc > maxIMC){
            maxIMC = imc;
            NODE_MAX = tmp;
        }
        tmp = tmp->next;
    }
    

    printf("\n\nIMC Massimo:\n");
    printf("%s %s %d %d %d %c\n", NODE_MAX->data.nome, NODE_MAX->data.cognome, NODE_MAX->data.età, NODE_MAX->data.peso, NODE_MAX->data.altezza, NODE_MAX->data.sesso);
    
    insertB(ListaB, NODE_MAX->data);
    delete(Lista, NODE_MAX->data.età);
    
}



/*D. Inizializzi una nuova lista concatenata vuota B. Sposti i tre elementi con più alto indice di 
massa corporea dalla lista A alla lista B. Tali inserimenti vanno effettuati in testa. 
Suggerimento: lo spostamento può essere effettuato ripetendo per tre volte le operazioni di 
ricerca dell’elemento con più alto indice di massa corporea, inserimento di copia */

void visitList(list* Lista, list* ListaB){
    nodo* tmp = Lista->head;
    printf("\n\nContenuto lista A: \n");
    while(tmp!=NULL){
        printf("%s %s %d %d %d %c\n", tmp->data.nome, tmp->data.cognome, tmp->data.età, tmp->data.peso, tmp->data.altezza, tmp->data.sesso);
        tmp = tmp->next;
    }

    nodo* tmp2 = ListaB->head;
    printf("\n\nContenuto lista B: \n");
    while(tmp2!=NULL){
        printf("%s %s %d %d %d %c\n", tmp2->data.nome, tmp2->data.cognome, tmp2->data.età, tmp2->data.peso, tmp2->data.altezza, tmp2->data.sesso);
        tmp2 = tmp2->next;
    }

    
}


void writeFile(list* ListaB, Arg ag){

    FILE* filePtr = fopen(ag.file_output,"w");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    nodo* tmp = ListaB->head;
    while(tmp!=NULL){
        fprintf(filePtr, "%s %s %d %d %d %c\n", tmp->data.nome, tmp->data.cognome, tmp->data.età, tmp->data.peso, tmp->data.altezza, tmp->data.sesso);
        tmp = tmp->next;
    }

    fclose(filePtr);
}


int main(int argc, char*argv[]){

    Arg ag = decodeParameters(argc, argv); 
    printf("File input: %s\nFile output: %s\n", ag.file_input, ag.file_output);

    list* Lista = getList();

    Lista = readFile(Lista, ag);
    
    list* ListaB = getList();

    for(int i = 0; i < 3; i++){
    getMax(Lista, ListaB);
    }

    visitList(Lista, ListaB);


    writeFile(ListaB, ag);


}


/*26 min rimasti*/