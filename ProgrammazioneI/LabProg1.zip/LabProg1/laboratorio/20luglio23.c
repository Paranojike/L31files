#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef struct Argomenti{
    int n;
    int m;
}Arg;


Arg decodeparameters(int argc, char*argv[]) {

    if(argc!=3) {
        fprintf(stderr, "NUMERO ARGOMENTI ERRATO\n");
        exit(-1);
    }

    Arg in;

    in.n = atoi(argv[1]); 
    in.m = atoi(argv[2]); 


    if(in.n < 3 || in.n > 7) {
        fprintf(stderr, "VALORE N ERRATO\n");
        exit(-1);
    }

    if(in.m < 3 || in.m > 7) {
        fprintf(stderr, "VALORE M ERRATO\n");
        exit(-1);
    }

    return in;

}



unsigned int get_random() {
    static unsigned int m_w = 424242;
    static unsigned int m_z = 242424;
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}


int*** getRandomMatrix(Arg ag) {



    int h = 0;
    printf("\nInserire un valore h compreso tra 10 e 100: ");
    scanf("%d", &h);

    while(h < 10 || h > 100) {
        printf("Valore h errato\nInserire un valore compreso tra 10 e 100\n"); 
        scanf("%d", &h);
    }


    //allocazione della matrice
    int ***M = malloc(sizeof(int **) * ag.n);
    for (int i = 0; i < ag.n; i++) {
        M[i] = malloc(sizeof(int *) * ag.m);
        for (int j = 0; j < ag.m; j++) {
            M[i][j] = malloc(sizeof(int));
        }
    }


    //riempimento della matrice
    for(int i = 0; i<ag.n; i++) {
        for(int j = 0; j<ag.m; j++) {
            *(M[i][j]) = get_random()%(h+1);  //viene aggiunto +1 è perché l'operatore modulo % genera un numero compreso tra 0 e h
        }
    }


    //stampa della matrice
    for(int i = 0; i<ag.n; i++) {
        for(int j = 0; j<ag.m; j++) {
            printf("%d\t", (*M[i][j]));
        }
        printf("\n");
    }


return M;
}



/*C. Elimini in ciascuna colonna 𝑗 di A i tre valori più grandi della colonna. L’eliminazione di un 
elemento 𝐴[𝑖][𝑗] della matrice va effettuata ponendo a NULL l’elemento 𝐴[𝑖][𝑗] e liberando 
la memoria occupata dall’intero puntato da A[i][j]. SUGGERIMENTO: è possibile rimuovere 
i tre elementi più grandi effettuando tre volte la ricerca del massimo ed eliminando di volta in 
volta il valore trovato. */


void removeMax(int***A, int max, int j){


    free(A[max][j]);
    A[max][j] = NULL;

}


void modifymatrix(int*** A, Arg ag){

/*A[i][j] != NULL:
Verifica che l'elemento corrente A[i][j] non sia un puntatore NULL, perché un puntatore NULL significa che l'elemento è stato rimosso (liberato) e non dovrebbe essere considerato nel confronto.

(A[max][j] == NULL || *(A[i][j]) > *(A[max][j])):

A[max][j] == NULL: Verifica se l'elemento attualmente considerato come massimo (A[max][j]) è NULL. Se è NULL, significa che il massimo non è stato ancora impostato o è stato rimosso, quindi qualsiasi elemento non NULL può diventare il nuovo massimo.
*(A[i][j]) > *(A[max][j]): Se A[max][j] non è NULL, confronta il valore dell'elemento corrente A[i][j] con il valore dell'elemento massimo attuale A[max][j]. Se l'elemento corrente è maggiore, allora diventa il nuovo massimo.
Combinate insieme, queste condizioni assicurano che:

L'elemento corrente A[i][j] viene considerato solo se non è NULL.
Se non abbiamo ancora un massimo (o il massimo attuale è NULL), il primo elemento non NULL diventa il massimo.
Se abbiamo già un massimo, l'elemento corrente deve essere confrontato con il massimo attuale, e diventa il nuovo massimo solo se è maggiore.*/

   for(int j = 0; j < ag.m; j++) {
        int max = 0;
        for(int i = 0; i < 3; i++) {
            for(int i = 0; i < ag.n ; i++) {
                if (A[i][j] != NULL && (A[max][j] == NULL || *(A[i][j]) > *(A[max][j]))) {
                    max = i;   
                }
            } 
        removeMax(A, max, j);
    }
}

    printf("\n\n");
    for(int i = 0; i < ag.n; i++){
        for(int j= 0; j< ag.m; j++){
            if(!A[i][j])
                printf("*\t");
            else
                printf("%d\t", *(A[i][j]));
            
        }
        printf("\n");
    }

}


/*D. Si stampino su standard output i valori della riga contenente il numero minore di valori NULL. 
NOTA: qualora più righe dovessero avere lo stesso numero 𝑥 di valori NULL, sarà sufficiente 
stampare una qualsiasi riga contenente 𝑥 valori NULL. */

void rowMinNull(int*** A, Arg ag){

unsigned int min = UINT_MAX;
unsigned int riga = 0;

for(int i = 0; i < ag.n; i++){
    int counter = 0;
    for(int j = 0; j < ag.m; j++){
        if(A[i][j] == NULL){
            counter++;
        }
    }
    if(counter < min){
        min = counter;
        riga = i;
    }
}
printf("la riga con meno * è %d\n",riga);

}


int main(int argc, char*argv[]) {

    Arg ag = decodeparameters(argc, argv);
    printf("Valore N: %d\nValore M: %d\n", ag.n, ag.m);

    int*** A = getRandomMatrix(ag);

    
    modifymatrix(A, ag);

    rowMinNull(A, ag);
    

}





int i, j, temp;
// Ciclo esterno per ripetere il processo N-1 volte
for (i = 0; i < size - 1; i++) {
    // Ciclo interno per confrontare gli elementi adiacenti
    for (j = 0; j < size - i - 1; j++) {
        // Se l'elemento corrente è maggiore dell'elemento successivo, scambiali
        if (array[j] > array[j + 1]) {
            // Utilizzo di una variabile temporanea per lo scambio
            temp = array[j];
            array[j] = array[j + 1];
            array[j + 1] = temp;
        }
    }
}
