#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Argomenti{
    char file_input[255];
    char file_output[255];
}Arg;


Arg decodeParameters(int argc, char* argv[]){

    if(argc!=3){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg in;

    strcpy(in.file_input, argv[1]);
    strcpy(in.file_output, argv[2]);

    if(strcmp(strrchr(in.file_input, '.'), ".txt")){
        fprintf(stderr, "Estensione file input errata\n");
        exit(-1);
    }

    if(strcmp(strrchr(in.file_output, '.'), ".txt")){
        fprintf(stderr, "Estensione file output errata\n");
        exit(-1);
    }

return in;
}


 //nei parametri della funzione chiamata
//uso * nelle variabili che avevo mandato con &
void readHeader(FILE* filePtr, int* n, int* m){  
    fscanf(filePtr, "%d %d", n, m);
}


double*** readFile(Arg ag, int* n, int* m){

    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    readHeader(filePtr, n, m);
    int N = *(n);
    int M = *(m);

    double*** X = malloc(sizeof(double**) * N);
    for(int i = 0 ; i < N; i++){
        X[i] = malloc(sizeof(double*) * M);
            for(int j = 0; j < M; j++){
                X[i][j] = malloc(sizeof(double));
            }
        }
    
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            fscanf(filePtr, "%lf", X[i][j]);
        }
    }


    printf("\n");
    for(int i = 0; i < N ; i++){
        for(int j = 0; j < M ; j++){
            printf("%.2lf\t", *(X[i][j]));
        }
        printf("\n");
    }

return X;
}




double* getArray(double*** X, int n, int m){

    double* Y = malloc(sizeof(double) * n);

    for(int i = 0; i < n; i++){
        double med = 0;
        for(int j = 0; j < m; j++){
            med += *(X[i][j]);
        }
        Y[i] = med / m;
    }

    printf("\nContenuto array\n");
    for(int i = 0; i < n; i++){
        printf("%.2lf\t", Y[i]);
    }
    printf("\n");
return Y;
}



void selectionSort(double* Y, int n){

double tmp = 0;
for(int i = 0; i < n-1; i++){
    int min = i;
    for(int j = i+1; j < n; j++){
        if(Y[j] < Y[min]){
            min = j;
        }
    }
    tmp = Y[i];
    Y[i] = Y[min];
    Y[min] = tmp;
}

printf("\n\nContenuto array ordinato\n");
    for(int i = 0; i < n; i++){
        printf("%.2lf\t", Y[i]);
    }
    printf("\n");

}


void processX(double* Y, double*** X, int n, int m){

    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++){
            if(*(X[i][j]) > Y[i]){
                X[i][j] = NULL;
            }
        }
    }



    printf("\n\n");
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++){
            if(X[i][j] == NULL){
                printf("*\t");
            }else{
                printf("%.2lf\t", *(X[i][j]));
            }
        }
        printf("\n");
    }



}

void writeToFile(double***X, int n, int m, Arg ag){

    FILE* filePtr = fopen(ag.file_output, "w");
    if(filePtr == NULL){
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }


    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++){
            if(X[i][j] == NULL){
                fprintf(filePtr, "*\t");
            }else{
                fprintf(filePtr, "%.2lf\t", *(X[i][j]));
            }
        }
        fprintf(filePtr, "\n");
    }


}


int main(int argc, char* argv[]){
    Arg ag = decodeParameters(argc, argv);
    printf("======A Stampa Parametri======\ninput_filename = %s\noutput_filename = %s\n", ag.file_input, ag.file_output);

    int n, m;
    double*** X = readFile(ag, &n, &m);

    double* Y = getArray(X, n, m);

    selectionSort(Y, n);

    processX(Y, X, n, m);

    writeToFile(X, n, m, ag);

}