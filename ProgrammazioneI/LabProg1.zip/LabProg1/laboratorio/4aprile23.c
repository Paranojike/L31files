/*A. Prenda in input da riga di comando due parametri interi n e m e un parametro stringa filename 
che contenga un nome di file di input (ad esempio “file_di_input.txt”). Il programma controlli 
che i parametri n e m siano interi compresi tra 3 e 7 inclusi e che il nome del file di input abbia 
estensione “txt”. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Argomenti{
    int n;
    int m;
    char file_input[255];
}Arg;

Arg decodeParameters(int argc, char* argv[]) {

    if(argc!=4) {
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg ag;

    ag.n = atoi(argv[1]);
    ag.m = atoi(argv[2]);
    strcpy(ag.file_input, argv[3]);

    if(ag.n < 3 || ag.n > 7) {
        fprintf(stderr, "Intervallo di N errato\n");
        exit(-1);
    }

    if(ag.m < 3 || ag.m > 7) {
        fprintf(stderr, "Intervallo di M errato\n");
        exit(-1);
    }

    if(strcmp(strrchr(ag.file_input,'.'),".txt")){
        fprintf(stderr, "Estensione file errata\n");
        exit(-1);
    }

return ag;

}


/*B. Si assuma che il file di testo contenuto al percorso indicato da filename contenga n righe, 
ciascuna contenente m double separati da virgole. Il programma legga il contenuto del file e 
lo inserisca all’interno di un matrice X di double di dimensione 𝑛	× 𝑚. */

double** readFile(Arg ag){

    double** M = malloc(sizeof(double*)* ag.n);
    for(int i = 0; i < ag.m; i++) {
        M[i] = malloc(sizeof(double) * ag.m);
    }


    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL) {
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    for(int i = 0; i < ag.n; i++) {
        for(int j = 0; j < ag.m; j++){
            fscanf(filePtr, "%lf,", &M[i][j]);
        }
    }

    for(int i = 0; i < ag.n; i++){
        for(int j = 0; j < ag.m; j++){
            printf("%.3lf\t", M[i][j]);
        }
        printf("\n");
    }

    fclose(filePtr);

return M;
}


/*C. Definisca un array Y di n interi e inserisca in Y[i] il numero di elementi nella riga i-esima di 
X che hanno un valore compreso tra a e b (esclusi), dove a= q – (max-min)*0.3 e b= q+(max
min)*0.3, e q, min, e max sono rispettivamente il valore medio, minimo e massimo della riga 
i-esima di X. (L’operazione va effettuata per ciascun valore di i)*/


float calculateA(float min, float max, float q){

    float a = q - (max-min) * 0.3;

return a;
}

float calculateB(float min, float max, float q){

    float b = q + (max-min) * 0.3;

return b;
}

int* getArray(double** X, Arg ag){

    int* A = malloc(sizeof(int) * ag.n);
    for(int i = 0; i < ag.n ; i++){
        float min = 0;
        float max = 0;
        float q = 0;

        for(int j = 0; j < ag.m; j++){
            if(X[i][j] > max) {
                max = X[i][j];
            }
            
            if(X[i][j] < min) {
                min = X[i][j];
            }
            q += X[i][j];
        }

        q = q/ag.m;
        float a = calculateA(min, max, q);
        float b = calculateB(min, max, q);
        int counter = 0;
        for(int x = 0; x < ag.m; x++) {
            if(X[i][x] > a && X[i][x] < b) {
                counter++;
            }
        }

        A[i] = counter;
    }

    for(int i = 0; i < ag.n; i++) {
        printf("%d\t", A[i]);
    }
    printf("\n");

    return A;
}



void insertionSort(int* Y, Arg ag){

    for(int i = 1; i < ag.n; i++){
        int key = Y[i];
        int j = i-1;
        while(j >= 0 && Y[j] > key){
            Y[j+1] = Y[j];
            j = j-1;
        }
        Y[j+1] = key;
    }

printf("\n");
    for(int i = 0; i < ag.n; i++) {
        printf("%d\t", Y[i]);
    }
    printf("\n");

}


int* getCumulative(int* Y, Arg ag) {
    

    int* Q = malloc(sizeof(double) * ag.n);
    for(int i = 0; i < ag.n; i++) {
        Q[i] = 0;
    }
    printf("\n");

    for(int i = 0; i < ag.n; i++) {
        Q[i] = Y[i] + Q[i-1];
    }


return Q;
}



int main(int argc, char* argv[]) {

    Arg ag = decodeParameters(argc, argv);
    printf("Nome file input: %s\nParametro N: %d\nParametro M: %d\n", ag.file_input, ag.n, ag.m);

    double** X = readFile(ag);

    int* Y = getArray(X, ag);

    insertionSort(Y, ag);

    int* Z = getCumulative(Y, ag);
    for(int i = 0; i < ag.n; i++){
    printf("%d\t", Z[i]);
    }
    printf("\n");

    for(int i = 0; i < ag.n; i++){
        free(X[i]);  //se doppio puntatore un solo for, se triplo puntatore, doppio for
    }
    free(X);

    free(Y);

    free(Z);


}