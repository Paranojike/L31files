/*. Prenda in input da riga di comando un parametro stringa simboli, un intero n e un nome di file 
output (ad esempio “file_di_output.txt”). Il programma controlla che la stringa simboli abbia 
una lunghezza L compresa tra 10 e 20 caratteri (inclusi) e che l’intero n sia compreso tra 8 e 
18 (inclusi). Se i parametri passati non rispettano i requisiti richiesti, il programma stampa un 
messaggio di error*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


typedef struct Argomenti{

    char simboli[255];
    int n;
    char file_output[255];

}Arg;

typedef struct Nodo{
    char* data;
    struct Nodo* next;
}nodo;


typedef struct Lista{
    nodo* head;
}list;


Arg decodeParameters(int argc, char* argv[]) {

    if(argc!=4) {
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg ag;

    strcpy(ag.file_output, argv[3]);
    ag.n = atoi(argv[2]);
    strcpy(ag.simboli, argv[1]);

    if(ag.n < 8 || ag.n > 18) {
        fprintf(stderr, "Parametro N errato\n");
        exit(-1);
    }

    if(strlen(ag.simboli) < 10 || strlen(ag.simboli) > 20) {
        fprintf(stderr, "Lunghezza stringa errata\n");
        exit(-1);
    }

return ag;

}


int getFactorial(int x){

    if(x <= 0) {
        return 1;
    } else {
        return x * getFactorial(x-1);
    } 
}

int* readInput(Arg ag) {

    int* W = malloc(sizeof(int) * ag.n);


    printf("Inserire %d numeri interi\n", ag.n);
    for(int i = 0; i < ag.n; i++){
        scanf("%d", &W[i]);
    }

    for(int i = 0; i < ag.n; i++){
        W[i] = getFactorial(W[i]);
    }


    printf("\n");
    for(int i = 0; i < ag.n; i++){
        printf("%d\n", W[i]);
    }
return W;
}




unsigned int get_random() {
    static unsigned int m_w = 424242;
    static unsigned int m_z = 242424;
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}


char* sampleString(char* simboli, int h) {


    char* Stringa = malloc(sizeof(char) * h);
    int L = strlen(simboli);

    for(int i = 0; i < h; i++) {
        unsigned int rndindx = get_random() % L;
        Stringa[i] = simboli[rndindx];
    }

return Stringa;
}


char** getStringArray(int* W, Arg ag) {

    int L = strlen(ag.simboli);
    char** S = malloc(sizeof(char*) * ag.n);
    for(int i = 0; i < ag.n; i++){
        int h = W[i] % L;
        S[i] = malloc(sizeof(char) * h);
        S[i] = sampleString(ag.simboli, h);
    }

return S;
}




list* getPila(void){

    list* Pila = malloc(sizeof(list));
    if(Pila == NULL){
        fprintf(stderr, "Impossibile allora Pila\n");
        exit(-1);
    }

    Pila->head = NULL;

return Pila;
}


void push(char* Qstr, list* Lista) {

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL) {
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = Qstr;

    if(Lista->head == NULL) {
        newnode->next = NULL;
        Lista->head = newnode;
    }else {
        newnode->next = Lista->head;
        Lista->head = newnode;
    }

}


char* createString(char* a, char* Qi) {

    char* B = malloc(sizeof(char) * strlen(a));

    for(int i = 0; i < strlen(a); i++) {
        if(Qi[i] == a[i]) {
            B[i] = a[i];
        }
    }
return B;
}


char* pop(list* Lista) {

    if(Lista->head == NULL) {
        fprintf(stderr, "Lista vuota\n");
        exit(-1);
    }

    char* streturn = Lista->head->data;

    nodo* tmp = Lista->head;
    Lista->head = tmp->next;
    free(tmp);

return streturn;
}

void getStack(list* Lista, char** Q, Arg ag) {

   for(int i = 0; i < ag.n; i++) {
        if(strlen(Q[i]) % 2 == 0 || Lista->head == NULL) {
            push(Q[i], Lista);
        } else {
            char* a = pop(Lista);
            char* b = createString(a,Q[i]);
            push(b, Lista);
        }
   }


}



void visitList(list* Lista) {

    nodo* tmp = Lista->head;
    while(tmp!=NULL){
        printf("%s\n", tmp->data);
        tmp = tmp->next;
    }

}


void writeStackToFile(list* Lista, Arg ag) {

    FILE* filePtr = fopen(ag.file_output, "w");
    if(filePtr == NULL) {
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    nodo* tmp = Lista->head;
    while(tmp!=NULL){
        fprintf(filePtr, "%s\n", tmp->data);
        tmp = tmp->next;
    }

    fclose(filePtr);

}

int main(int argc, char* argv[]) {

    Arg ag = decodeParameters(argc, argv);
    printf("Nome file: %s\nParametro N: %d\nStringa: %s\n", ag.file_output, ag.n, ag.simboli);

    int* W = readInput(ag);

    char** Q = getStringArray(W, ag);
   
    list* Lista = getPila();

    getStack(Lista, Q, ag);

    visitList(Lista);

    writeStackToFile(Lista, ag);


    free(W);

    for(int i = 0; i < ag.n; i++){
        free(Q[i]);
    }
    free(Q);

    while(Lista->head!=NULL){
        nodo* tmp = Lista->head;
        Lista->head = Lista->head->next;
        free(tmp->data);
        free(tmp);
    }
    free(Lista);


}

/*1 ora*/