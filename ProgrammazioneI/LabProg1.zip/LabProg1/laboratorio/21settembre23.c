#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Argomenti{
    int min;
    int max;
    int n;
}Arg;

/*A. Prenda in input come argomenti un parametro intero min compreso tra 7 e 12 (inclusi), un 
parametro intero max compreso tra 7 e 12 (inclusi), e un parametro intero n positivo e diverso 
da zero. Il programma deve verificare che min, max e n siano numeri interi con le 
caratteristiche specificate, che min<max. */

Arg decodeparameters(int argc, char* argv[]){

    if(argc!=4){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg in;

    in.min = atoi(argv[1]);
    in.max = atoi(argv[2]);
    in.n = atoi(argv[3]);

    if(in.min < 7 || in.min > 12){
        fprintf(stderr, "Parametro min errato\n");
        exit(-1);
    }
    if(in.max < 7 || in.max > 12){
        fprintf(stderr, "Parametro max errato\n");
        exit(-1);
    }

    if(in.n <= 0){
        fprintf(stderr, "Parametro n errato\n");
        exit(-1);
    }

    if( in.min > in.max ){
        fprintf(stderr, "Parametro min maggiore di max\n");
        exit(-1);
    }

    return in;
}


unsigned int get_random() {
    static unsigned int m_w = 424242;
    static unsigned int m_z = 242424;
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;
}

char* generateString(char* S, int x){

char vocali[5] = {'a', 'e', 'i', 'o', 'u'};
for(int i = 0; i < x; i++){
    unsigned int rand = get_random() % 5;
    S[i] = vocali[rand];
}

return S;
}

char** makeArray(Arg ag){

    char** M = malloc(sizeof(char*) * ag.n);
    for(int i = 0; i < ag.n; i++){
        int x = ag.min + get_random() % (ag.max - ag.min + 1);
        M[i] = malloc(sizeof(char) * x);
        M[i] = generateString(M[i], x);
    }

    for(int i = 0; i < ag.n; i++){
        printf("%s\n", M[i]);
    }
return M;
}


void sortArray(char* Str){

    for(int i = 1; i < strlen(Str); i++){
        char key = Str[i];
        int j = i-1;
        while( j >= 0 && Str[j] > key){
            Str[j] = Str[j+1];
            j -= 1;
        }
        Str[j+1] = key;
    }


}


char* concatString(char** A, Arg ag){
    
    int counter = 0;
    for(int i = 0; i < ag.n; i++){
        counter = counter + strlen(A[i]);
    }

    char* X = malloc(sizeof(char) * counter + ag.n);

    for(int i = 0; i < ag.n; i++){
        strcat(X,A[i]);
    }

return X;
}


void replaceCharacters(char* B){

    for(int i = 0; i < strlen(B); i++){
        if(B[i] == 'e' && B[i+1] == 'u'){
            B[i+1] = '*';
        }
    }

}

int main(int argc, char* argv[]){

    Arg ag = decodeparameters(argc, argv);
    printf("Parametri inseriti: min=%d, max=%d, n=%d\n", ag.min, ag.max, ag.n);

    char** A = makeArray(ag);

    printf("\n");   
    char* B = concatString(A, ag);
    printf("%s\n", B);

    printf("\n");    

    for(int i = 0; i < ag.n; i++){
    sortArray(A[i]);
    }
    
    for(int i = 0; i < ag.n; i++){
    printf("%s\n", A[i]);
    }

    replaceCharacters(B);
    printf("%s\n", B);



/*1 h rimasta*/

}