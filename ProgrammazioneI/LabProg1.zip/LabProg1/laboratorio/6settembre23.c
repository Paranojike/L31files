#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct Nodo{
    float data;
    struct Nodo* next;
}nodo;

typedef struct Lista{
    nodo* head;
}list;



typedef struct Argomenti{
    int n;
    char file_input[255];
}Arg;


Arg decodeParameters(int argc, char* argv[]){

    if(argc!=3){
        fprintf(stderr, "Numero argomenti errato\n");
        exit(-1);
    }

    Arg ag;

    ag.n = atoi(argv[1]);
    strcpy(ag.file_input, argv[2]);

    if(ag.n < 5 || ag.n > 20) {
        fprintf(stderr, "Intervallo N errato\n");
        exit(-1);
    }

    if(strcmp(strrchr(ag.file_input,'.'),".dat")){
        fprintf(stderr, "Estensione file errata\n");
        exit(-1);
    }

    return ag;

}




int* readFile(Arg ag){

    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL) {
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    int counter = 0;
    while(1){
        int buffer = 0;
        fscanf(filePtr, "%d", &buffer);
        counter++;
        if(feof(filePtr)) break;
    }
    

    rewind(filePtr);

    int* Y = malloc(sizeof(int) * counter);
    for(int i = 0; i < counter; i++){
        fscanf(filePtr, "%d", &Y[i]);
    }

    printf("Contenuto Array\n");
    for(int i = 0; i < counter; i++){
        printf("%d\n", Y[i]);
    }

    fclose(filePtr);

return Y;

}

int getCounter(Arg ag){

    FILE* filePtr = fopen(ag.file_input, "r");
    if(filePtr == NULL) {
        fprintf(stderr, "Impossibile aprire il file\n");
        exit(-1);
    }

    int counterfile = 0;
    while(1){
        int buffer = 0;
        fscanf(filePtr, "%d", &buffer);
        counterfile++;
        if(feof(filePtr)) break;
    }

return counterfile;

}

list* getList(void){

    list* Lista = malloc(sizeof(list));
    if(Lista == NULL){
        fprintf(stderr, "Impossibile allocare lista\n");
        exit(-1);
    }

    Lista->head = NULL;

return Lista;
}

/*C. Inizializzi una pila di float P e inserisca al suo interno l’elemento A[0]. Scorra gli elementi di 
A dal secondo all’ultimo. Dato l’elemento A[i], il programma controlli che tale elemento sia 
un multiplo del parametro n. Se A[i] è un multiplo di n, il programma lo inserisce in cima alla 
pila, altrimenti, il programma estrae (con una operazione di pop) l’elemento in cima alla pila 
(sia esso x) e inserisce in pila (con una operazione di push), la media aritmetica tra x e A[i].*/

void push(int A, list* Pila){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = A;

    if(Pila->head == NULL){
        newnode->next = NULL;
        Pila->head = newnode;
    }else {
        newnode->next = Pila->head;
        Pila->head = newnode;
    }   

}

float findMed(int x, int A){

    float media = (x+A) / 2;

return media;
}


int pop(list* Pila){

    if(Pila->head == NULL){
        fprintf(stderr, "Impossibile allocare lista\n");
        exit(-1);
    }

    int num = Pila->head->data;

    nodo* tmp = Pila->head;
    Pila->head = tmp->next;
    free(tmp);
    return num;
}

list* createStack(list* Pila, int* A, int counter, Arg ag){

push(A[0], Pila);
for(int i = 1; i < counter; i++){
    if(A[i] % ag.n == 0){
        push(A[i], Pila);
    }else{
        float x = pop(Pila);
        float med = findMed(x, A[i]);
        push(med, Pila);
    }
}


    nodo* tmp = Pila->head;
    printf("Contenuto Lista:\n");
    while(tmp!=NULL){
        printf("%.2f\n", tmp->data);
        tmp = tmp->next;
    }


return Pila;
}





/*findMinMaxMean: funzione che prende in input un riferimento alla pila e restituisce al 
chiamante il valore massimo, minimo e medio della pila.*/

void findMinMaxMean(list* Pila) {

    
    nodo* tmp = Pila->head;
    float min = tmp->data;
    float max = tmp->data;
    float med = 0;
    int counter = 0;


    while(tmp!=NULL){
        med += tmp->data;
        if(tmp->data > max){
            max = tmp->data;
        }
        if(tmp->data < min){
            min = tmp->data;
        }
        counter++;
        tmp = tmp->next;  
    }
    printf("media: %f\n", med);
    med = med/counter;
    printf("Valore massimo: %.2f\nValore minimo: %.2f\nValore medio: %.2f\n", max, min, med);

}



int main(int argc, char* argv[]) {

Arg ag = decodeParameters(argc, argv);
printf("Nome file: %s\nParametro N: %d\n", ag.file_input, ag.n);

int* A = readFile(ag);

int counter = getCounter(ag);

list* Pila = getList();

Pila = createStack(Pila, A, counter, ag);

findMinMaxMean(Pila);


}