#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Argomenti {
    int n;
    char filename[255];
}Arg;

typedef struct Nodo {
    float data;
    struct Nodo* next; 
}nodo;


typedef struct {
    nodo* head;
} Lista;


Arg decodeparameters(int argc, char*argv[]) {

    if(argc!=3) {
        fprintf(stderr, "NUMERO ARGOMENTI PASSATI ERRATO.\n");
        exit(-1);
    }

    Arg in;


    in.n = atoi(argv[1]);
    strcpy(in.filename, argv[2]);

    if (in.n < 5 || in.n > 20) {
            fprintf(stderr, "PARAMENTRO N ERRATO\n");
            exit(-1);
        }


    if(strcmp(strrchr(in.filename, '.'), ".dat")){
            fprintf(stderr, "ESTENSIONE FILE ERRATA\n");
            exit(-1);
        }

    return in;
}

int readlen(Arg ag) {

    FILE* filePtr = fopen(ag.filename, "r");
    if(filePtr==NULL) {
        fprintf(stderr, "NULL FILE\n");
        exit(-1);
    }

    int counter = 0;
    while(!feof(filePtr)){
        fscanf(filePtr, "%d", &(int){0});
        counter++;
    }

    printf("\nCounter: %d", counter);
    printf("\n");

    fclose(filePtr);

    return counter;
}

int* readInput(Arg ag, int len) {

    int* Arr = malloc(sizeof(int) * len);

    FILE* filePtr = fopen(ag.filename, "r");
    if(filePtr==NULL) {
        fprintf(stderr, "NULL FILE\n");
        exit(-1);
    }

    for(int i = 0; i<len; i++){
        fscanf(filePtr, "%d", &Arr[i]);
    }

    for(int i = 0; i<len; i++){
        printf("%d\n", Arr[i]);
    }

    return Arr;
}



//**********************************************************************************************************


Lista* newlist() { 

    Lista* list= malloc(sizeof(Lista));
    if (list == NULL) {
        fprintf(stderr, "Errore di allocazione della memoria\n");
        exit(-1);
    }

    (list)->head = NULL;

return list;
}


//**********************************************************************************************************

void push(Lista* list, float dato) {

    nodo* newnode = (nodo*)malloc(sizeof(nodo));
    

    if (newnode == NULL) {
        fprintf(stderr, "Errore di allocazione della memoria\n");
        exit(-1);
    }

    newnode->data = dato;


    if(list->head == NULL) {
        newnode->next = NULL;
        list->head = newnode;
    } else {
        newnode->next = list->head; //lista -> head equivale a dire puntatore di tipo nodo a head
        list->head = newnode;
    }
}


//**********************************************************************************************************



float pop(Lista* list) {

    if(list->head == NULL) {
        fprintf(stderr, "LISTA VUOTA\n");
        exit(-1);
    }

    float f = list->head->data; //prendi il dato che è nella testa, per fare il pop ti serviva il node tmp a cui si assegna head, poi manda avanti head

    nodo* tmp = list->head;
    list->head = tmp->next;
    free(tmp);

    return f;
}


//**********************************************************************************************************


float calcolamed(float a, float b) {

    float media = (a+b) / 2;

return media;
}



//**********************************************************************************************************



Lista* createStack(Lista* list, int* A, int len, Arg ag) { //non so quale riferimento devo fare tornareeeee

    push(list, A[0]);

    for(int i = 1; i < len; i++) {
        if(A[i] % ag.n == 0) {
            push(list, A[i]);
        } else {
            float x = pop(list);
            float y = calcolamed(x, A[i]);
            push(list, y);
        }
    }
return list;
}





void printstack(Lista* list) {

    nodo* tmp = list->head;

    while(tmp!=NULL) {
        printf("%.2f\n", tmp->data);
        tmp = tmp->next;
    }
    free(tmp);

}



int main (int argc, char*argv[]) {

    Arg ag = decodeparameters(argc, argv);
    printf("Parametro N: %d\nNome file: %s\n", ag.n, ag.filename);

    /*readInput: funzione che legge i numeri contenuti nel file di input e restituisce un array A 
    contenente tali numeri;*/
    int len = readlen(ag);

    int* A = readInput(ag, len);

    Lista* list = newlist();

    list = createStack(list, A, len, ag);

    printstack(list);
    

    

}