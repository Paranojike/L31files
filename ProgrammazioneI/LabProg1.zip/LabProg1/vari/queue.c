#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 10

typedef struct Nodo {
    int n;
    struct Nodo* next;
} nodo;


typedef struct lista {
    nodo* head;
}Lista;

void enqueue (int num, Lista* list) {

    nodo* newnode = malloc(sizeof(nodo));
    newnode->data = num;
    
    newnode->next= NULL;

    if(list->tail == NULL){
        list->head = newnode;
        list->tail = newnode;
    }
    else{
        list->tail->next = newnode;   //il valore next puntato da tail deve spostarsi a newnode
        list->tail = newnode; // sposta anche tail a newnode e alla fine di questa operazione sia tail che newnode puntano al nuovo nodo
    }
    
}


int dequeue (Lista* list) {   //uguale alla pop

    int numero = list->head->data;
    
    nodo* tmp = list->head;  //copia la testa in un tmp
    list->head = list->head->next; //sposta avanti la testa effettiva
    free(tmp); //elimina il nodo che stava in testa

    return numero;

}


void enqueue(list* queue, int num){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = num;
    newnode->next = NULL;


    //se non ci sono nodi nella coda, sia tail che head puntano al nuovo nodo
    if(queue->tail == NULL){
        queue->tail = newnode;
        queue->head = newnode;
    }else{
        queue->tail->next = newnode;
        tail->next = newnode;
    }

}