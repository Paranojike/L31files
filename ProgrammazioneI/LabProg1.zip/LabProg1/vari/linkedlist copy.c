#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

typedef struct Nodo {
    int n;
    struct Nodo* next;
} nodo;

typedef struct Lista {
    nodo* head;
}lista;





lista* insert(record r, lista* Lista) {

    nodo* newnode = malloc(sizeof(nodo));
    
    if(newnode == NULL) {
        fprintf(stderr, "Memoria insufficiente per allocare il nodo\n\n");
        exit(-1);
    }

    newnode->data = r;
    //nessun nodo nella lista
    if(Lista->head == NULL) {
        newnode->next = NULL;
        Lista->head = newnode;

    } else { //controllo se l'anno del nuovo nodo è minore di quello che sta già in testa
        if(newnode->data.anno_apertura <= Lista->head.anno_apertura) {
            newnode->next = Lista->head; //il newnode diventa la testa come in una stack
            Lista->head = newnode;

        } else {
            nodo*current = Lista->head;
            //finchè non trovi la posizione giusta... scorri la lista
            while(current->next != NULL && newnode->data.anno_apertura > current->next->data.anno_apertura) {
            current = current->next;
            }
            //quando hai trovato la posizione giusta, inserisci il nodo
            newnode->next = current->next;
            current->next = newnode;
        }
    }

    
return Lista;
}








/*TROVARE IL MASSIMO IN UNA LISTA*/


float getmax(lista* Lista ) {


nodo* current = Lista->head;


float max = current->data.saldo;

while(current->next != NULL) {

    if(current->next->data.saldo > max) {
        max = current->next->data.saldo;
    }
    current = current->next;
}

return max;
}







// Funzione per eliminare un nodo dalla lista in base al valore del numero del conto
void delete(int numero_conto, lista* Lista) {

    if(Lista->head == NULL) {
        fprintf(stderr, "LISTA VUOTA\n");
        exit(-1);
    }
    // Puntatori temporanei per attraversare la lista
    nodo* temp = Lista->head;
    nodo* prev = NULL;

    // Caso speciale: se il nodo da eliminare è il primo nella lista
    if (temp != NULL && temp->data.numero_conto == numero_conto) {
        Lista->head = temp->next; // Cambia l'inizio della lista
        free(temp); // Libera la memoria del nodo eliminato
        return;
    }

    // Cerchiamo il nodo da eliminare nella lista
    while (temp != NULL && temp->data.numero_conto != numero_conto) {
        prev = temp;
        temp = temp->next;
    }

    // Se il nodo da eliminare è presente nella lista, lo eliminiamo
    if (temp != NULL) {
        prev->next = temp->next; // Aggiorniamo il puntatore del nodo precedente al nodo da eliminare
        free(temp); // Liberiamo la memoria del nodo eliminato
    }
}



void removeAccount(lista* Lista) {



    float max = getmax(Lista);
    printf("\nMassimo saldo: %f\n", max);
    nodo* current = Lista->head;
    float massimoX = 0;
    nodo* nodoMassimoX = NULL;
    float x = 0;

    while(current!= NULL) {  
        x = findX(current->data.anno_apertura, max, current->data.saldo);
        if( x > massimoX) {
            massimoX = x;// Aggiorna il massimo valore di x trovato finora
            nodoMassimoX = current; // Aggiorna il puntatore al nodo con il massimo valore di x

        }
        current = current->next;
    }




if (nodoMassimoX != NULL) {  //// Se è stato trovato un nodo con il massimo valore di x, eliminiamolo dalla lista
        printf("\nEliminazione del nodo con il massimo valore di x: %.2f\n", massimoX);
        delete(nodoMassimoX->data.numero_conto, Lista); // Elimina il nodo con il massimo valore di x
    
    } else {
        printf("\nNessun nodo con il massimo valore di x trovato.\n");
    }



}























void insert(record r, lista* list){

    nodo* newnode = malloc(sizeof(nodo));
    if(newnode == NULL){
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }


    newnode->data = r;


    //nessun nodo in lista
    if(list->head == NULL){
        newnode->next = NULL;
        list->head = newnode;
    }else{
        if(newnode->data <= list->head->data){
            newnode->next = list->head;
            list->head = newnode;
        } else{
            nodo* current = list->head;
            while(current->next != NULL && newnode->data > current->next->data){
                current = current->next;
            }

            newnode->next = current->next;
            current->next = newnode;

        }   
    }


}



float delete(lista* list, int numero){

    if(list->head == NULL){
        fprintf(stderr, "Lista vuota\n");
        exit(-1);
    }

    float RetNum = 0;

    nodo* tmp = list->head;
    nodo* prev = NULL;

    //pop normale
    if(tmp!=NULL && list->head->data == numero){
        RetNum = tmp->data;
        list->head = tmp->next;
        free(tmp);
        return RetNum;
    }

    while(tmp!=NULL && list->head->data !=numero){
        prev = tmp;
        tmp = tmp->next;
    }

    if(tmp!=NULL){
        prev->next = tmp->next;
        RetNum = tmp->data;
        free(tmp);
    }


}




