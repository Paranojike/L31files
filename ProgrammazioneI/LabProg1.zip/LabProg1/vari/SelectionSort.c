

double tmp = 0;
    for(int i = 0; i < n-1; i++) {
        int min = i;
        for(int j = i+1; j < n; j++) {
            if(Y[j] < Y[min]) {
                min = j;
            }
        }
        tmp = Y[min];
        Y[min] = Y[i];
        Y[i] = tmp;
    }





