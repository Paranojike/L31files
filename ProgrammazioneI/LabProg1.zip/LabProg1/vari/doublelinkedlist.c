#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Nodo{
    record data;
    struct Nodo* next;
    struct Nodo* prev;
}nodo;


typedef struct Lista{
    nodo* head;
}list;




void insert(record r, lista* list) {
    
    nodo* newnode = malloc(sizeof(nodo));
    if (newnode == NULL) {
        fprintf(stderr, "Impossibile allocare nodo\n");
        exit(-1);
    }

    newnode->data = r;
    newnode->next = NULL;
    newnode->prev = NULL;

    // Case when the list is empty
    if (list->head == NULL) {
        list->head = newnode;
    } else {
        // Case when new node needs to be inserted at the beginning
        if (newnode->data <= list->head->data) {
            newnode->next = list->head;
            list->head->prev = newnode;
            list->head = newnode;
        } else {
            nodo* current = list->head;
            // Traverse to find the correct position for insertion
            while (current->next != NULL && newnode->data > current->next->data) {
                current = current->next;
            }

            newnode->next = current->next;
            newnode->prev = current;
            current->next = newnode;
            
            if (newnode->next != NULL) {
                newnode->next->prev = newnode;
            }
        }
    }
}


// Funzione per eliminare un nodo con un valore specifico
void delete(lista* list, int numero) {

    if (list->head == NULL) {
        fprintf(stderr, "Lista vuota\n");
        exit(-1);
    }

    nodo* tmp = list->head;
    // Caso di eliminazione del nodo in testa
    if (tmp != NULL && tmp->data == numero) {
        list->head = tmp->next;
        if (list->head != NULL) {
            list->head->prev = NULL;
        }
        free(tmp);
        return;
    }
    // Attraversa la lista per trovare il nodo da eliminare
    while (tmp != NULL && tmp->data != numero) {
        tmp = tmp->next;
    }

    // Nodo non trovato
    if (tmp == NULL) {
        fprintf(stderr, "Elemento non trovato\n");
        return;
    }

    // Nodo trovato e rimozione del nodo
    if (tmp->prev != NULL) {
        tmp->prev->next = tmp->next;
    }
    
    if (tmp->next != NULL) {
        tmp->next->prev = tmp->prev;
    }

    free(tmp);
}





#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Nodo{
	record data;
	struct Nodo* next;
	struct Nodo* prev;
}nodo;

typedef struct Lista{
	nodo* head;
}list;

// Funzione per inserire un nodo in una lista ordinata 
// (3 casi: lista vuota, inserimento in testa, inserimento in mezzo)
void insert(record r, lista* list) 
{
	// Allocazione di memoria per il nuovo nodo, controllo dell'allocazione ed inizializzazione
	nodo* newnode = malloc(sizeof(nodo));
	if (newnode == NULL) {
		perror("Impossibile allocare nodo\n");
		exit(-1);
	}
	newnode->data = r;
	newnode->next = NULL;
	newnode->prev = NULL;

//CASO 1 - lista vuota
//(basta controllare se la testa esiste, sennò il nuovo nodo diventa la testa)
	if (list->head == NULL)
		list->head = newnode;

	
//CASO 2 - inserimento in testa
//(basta controllare se il valore del nuovo nodo è 
//minore o uguale alla testa, sennò diventa la nuova testa)
	else
	{
		if (newnode->data <= list->head->data) 
		{		
		//	2 è la testa, voglio inserire 1

		//		2 ⇄ 3 ⇄ 5 ↦ NULL
		//   (testa)	
			
			newnode->next = list->head;
		//	1 ↦ 2 ⇄ 3 ⇄ 5 ↦ NULL
		//    (testa)	


			list->head->prev = newnode;
		//	1 ⇄	2 ⇄ 3 ⇄ 5 ↦ NULL
		//    (testa)	
								
			
			list->head = newnode;
		//	1 ⇄	2 ⇄ 3 ⇄ 5 ↦ NULL
		//(testa)     	
		}
		
		
		
//CASO 3 - inserimento in mezzo
//(scorro la lista per trovare la posizione corretta e inserire il nodo)
		else
		{
			nodo* current = list->head;
			
			// Scorro la lista per trovare la posizione corretta e inserire il nodo
			while (current->next != NULL && newnode->data > current->next->data) 
				current = current->next;

			newnode->next = current->next;
			newnode->prev = current;
			current->next = newnode;
			
			// Aggiornamento del campo prev del nodo successivo
			if (newnode->next != NULL) 
				newnode->next->prev = newnode;
		}
	}
}


// Funzione per eliminare un nodo con un valore specifico
void delete(lista* list, int numero) {

	if (list->head == NULL) {
		fprintf(stderr, "Lista vuota\n");
		exit(-1);
	}

	nodo* tmp = list->head;
	// Caso di eliminazione del nodo in testa
	if (tmp != NULL && tmp->data == numero) {
		list->head = tmp->next;
		if (list->head != NULL) {
			list->head->prev = NULL;
		}
		free(tmp);
		return;
	}
	// Attraversa la lista per trovare il nodo da eliminare
	while (tmp != NULL && tmp->data != numero) {
		tmp = tmp->next;
	}

	// Nodo non trovato
	if (tmp == NULL) {
		fprintf(stderr, "Elemento non trovato\n");
		return;
	}

	// Nodo trovato e rimozione del nodo
	if (tmp->prev != NULL) {
		tmp->prev->next = tmp->next;
	}
	
	if (tmp->next != NULL) {
		tmp->next->prev = tmp->prev;
	}

	free(tmp);
}