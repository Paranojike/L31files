

int i, key, j;

    for (i = 1; i < n; i++) 
    {
        key = arr[i];
        j = i - 1;
        /* Move elements of arr[0..i-1], that are greater than key, to one position ahead of 
           their current position */
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }






//insertion --> for esterno i = 1, i < n  //usa key e dichiara j = i-1 nel for esterno


//selection --> for esterno i = 0, i < n-1   --> for interno j = i+1; j < n   //usa min



